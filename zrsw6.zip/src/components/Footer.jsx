
import React from "react";

function Footer (){
    return (
      <footer>
      <p>Copyright by shapeAI @ 2021{new Date().getFullYear()} 
       </p>
      </footer>
    );
}
export default Footer;